﻿Imports System.Runtime.Serialization
Imports Newtonsoft.Json

Public Class HomeController
    Inherits System.Web.Mvc.Controller

    Private ReadOnly db As New NORTHWNDEntities
    Public Property GridData As Object
    Function Index() As ActionResult
        ViewBag.ordersData = (From orders In db.Orders Select New With {orders.OrderID, orders.CustomerID, orders.EmployeeID}).ToList()
        ViewBag.employeesData = (From employees In db.Employees Select New With {employees.EmployeeID, employees.FirstName, employees.LastName}).ToList()
        Return View()
    End Function

    Function About() As ActionResult
        ViewData("Message") = "Your application description page."

        Return View()
    End Function

    Function Contact() As ActionResult
        ViewData("Message") = "Your contact page."

        Return View()
    End Function
End Class