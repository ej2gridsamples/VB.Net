﻿Imports Syncfusion.EJ2.Base

Public Class HomeController
    Inherits System.Web.Mvc.Controller

    Public Shared order As New List(Of Orders)()
    Dim contracts
    Function Index() As ActionResult

        BindDataSource()
        Dim contracts = order
        Return View(contracts.ToList())
    End Function
    Public Function UrlDatasource(ByVal dm As DataManagerRequest) As ActionResult
        Dim DataSource As IEnumerable = order
        Dim operation As DataOperations = New DataOperations()

        If dm.Search IsNot Nothing AndAlso dm.Search.Count > 0 Then
            DataSource = operation.PerformSearching(DataSource, dm.Search)
        End If

        If dm.Sorted IsNot Nothing AndAlso dm.Sorted.Count > 0 Then
            DataSource = operation.PerformSorting(DataSource, dm.Sorted)
        End If

        If dm.Where IsNot Nothing AndAlso dm.Where.Count > 0 Then
            DataSource = operation.PerformFiltering(DataSource, dm.Where, dm.Where(0).[Operator])
        End If

        Dim count As Integer = DataSource.Cast(Of Orders)().Count()

        If dm.Skip <> 0 Then
            DataSource = operation.PerformSkip(DataSource, dm.Skip)
        End If

        If dm.Take <> 0 Then
            DataSource = operation.PerformTake(DataSource, dm.Take)
        End If

        If dm.RequiresCounts Then
            Return Json(New With {Key .result = DataSource, Key .count = count})
        Else
            Return Json(DataSource)
        End If
    End Function
    Function UrlUpdate(ByVal value As Orders) As ActionResult
        Dim data = order.Where(Function(p) p.OrderID = value.OrderID).FirstOrDefault()
        If data IsNot Nothing Then
            data.OrderID = value.OrderID
            data.CustomerID = value.CustomerID
            data.EmployeeID = value.EmployeeID
            data.Freight = value.Freight
            data.OrderDate = value.OrderDate
            data.ShipCity = value.ShipCity
        End If
        Return Json(value)
    End Function
    Public Function Insert(ByVal value As Orders) As ActionResult
        order.Insert(0, value)
        Return Json(value)
    End Function
    Public Sub Remove(ByVal key As Integer)
        Dim data = order.Where(Function([or]) [or].OrderID = key).FirstOrDefault()

        If data IsNot Nothing Then
            order.Remove(data)
        End If
    End Sub
    Function BindDataSource() As ActionResult
        Dim orderId As Integer = 10000
        Dim empId As Integer = 0
        Dim i As Integer = 1
        While i < 9
            order.Add(New Orders(orderId + 1, "VINET", empId + 1, 32.38, New DateTime(2014, 12, 25), "Reims"))
            order.Add(New Orders(orderId + 2, "TOMSP", empId + 2, 11.61, New DateTime(2014, 12, 21), "Munster"))
            order.Add(New Orders(orderId + 3, "ANATER", empId + 3, 45.34, New DateTime(2014, 10, 18), "Berlin"))
            order.Add(New Orders(orderId + 4, "ALFKI", empId + 4, 37.28, New DateTime(2014, 11, 23), "Mexico"))
            order.Add(New Orders(orderId + 5, "FRGYE", empId + 5, 67.0, New DateTime(2014, 5, 5), "Colchester"))
            order.Add(New Orders(orderId + 6, "JGERT", empId + 6, 23.32, New DateTime(2014, 10, 18), "Newyork"))
            orderId += 6
            empId += 6
            System.Math.Max(System.Threading.Interlocked.Increment(i), i - 1)
        End While

    End Function

    Function About() As ActionResult
        ViewData("Message") = "Your application description page."

        Return View()
    End Function

    Function Contact() As ActionResult
        ViewData("Message") = "Your contact page."

        Return View()
    End Function
    Public Class Orders
        Public Sub New()
        End Sub
        Public Sub New(orderId As Integer, customerId As String, empId As Integer, freight As Double, orderDate As DateTime, shipCity As String)
            Me.OrderID = orderId
            Me.CustomerID = customerId
            Me.EmployeeID = empId
            Me.Freight = freight
            Me.OrderDate = orderDate
            Me.ShipCity = shipCity
        End Sub
        Public Property OrderID() As Integer
        Public Property CustomerID() As String
        Public Property EmployeeID() As Integer
        Public Property Freight() As Double
        Public Property OrderDate() As DateTime
        Public Property ShipCity() As String
    End Class
End Class
